@echo off
setlocal
cd /d "%~dp0"
rem Native Windows drag-and-drop frontend; portable Python is provisioned on first build.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0USF2_Builder.ps1"
if errorlevel 1 (
  echo.
  echo Could not start the builder window. Please check your Windows PowerShell installation.
  pause
)
