USF2 RC3 FIX 5 - STARTUP ORDER REPAIR
===================================

This fixes the RC3 startup failure:
    ImportError: ffmpeg not found
    at Setup_Toolchain.ps1 line 85 during the early module check.

Cause: variant_music.py imports the FFmpeg-dependent ADX codec. The original
setup checked variant_music before downloading/locating FFmpeg, so first-run
initialization stopped before the program could install FFmpeg.

QUICK INSTALL
1. Close the builder.
2. Extract this hotfix ZIP.
3. Copy Setup_Toolchain.ps1 into your actual RC3 folder, such as:
       E:\USF2 Builder RC3\
   Replace the old file.
4. Do not delete _portable_tools. Re-run USF2_Builder.bat.

The corrected startup checks lightweight RC3 modules immediately after Python
setup. On All or MiSTer builds, it checks variant_music only after FFmpeg has
been provisioned. MAME-only/HBMAME-only builds don't import FFmpeg-dependent
music code during setup.

New log checkpoints:
   [TOOLS] RC3 core module imports: ready.
   [TOOLS] FFmpeg: ready.               (All/MiSTer only)
   [TOOLS] RC3 audio module imports: ready.  (All/MiSTer only)

All original RC3 kit scripts/manifest/payloads remain unchanged. HTTPS/Git TLS
verification stays enabled. This fix is targeted at the reported import failure;
it does not imply a completed Windows or game-image end-to-end test.
