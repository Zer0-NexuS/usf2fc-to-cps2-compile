#!/usr/bin/env python3
"""Minimal safe adapter for the unmodified USF2 rc2 reconstruction builder.

No game/NSP/key data are stored by this frontend.  It merely forwards paths.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shlex
import subprocess
import sys
from datetime import datetime
import uuid

HERE = Path(__file__).resolve().parent


def build_command(rom: Path, nsp: Path, keys: Path, output: Path, work: Path,
                  platform: str = 'all') -> list[str]:
    return [
        sys.executable, '-u', str(HERE / 'apply.py'),
        '--rompath', str(rom),
        '--nsp-us', str(nsp),
        '--keys', str(keys),
        '--out-dir', str(output),
        '--region', 'us',
        '--work', str(work),
        '--platform', platform,
    ]


def valid_file(value: str, description: str, suffixes: tuple[str, ...] = ()) -> Path:
    path = Path(value).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f'{description} does not exist: {path}')
    if suffixes and path.suffix.lower() not in suffixes:
        raise ValueError(f'{description} must end in {", ".join(suffixes)}: {path.name}')
    return path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rom', required=True, help='Merged / complete ssf2t.zip or compatible ZIP/7z archive')
    parser.add_argument('--nsp', required=True, help='USF2 USA base NSP')
    parser.add_argument('--keys', required=True, help='Your own prod.keys')
    parser.add_argument('--output-root', required=True, help='Existing or new parent folder for completed builds')
    parser.add_argument('--platform', choices=('all', 'mame', 'hbmame', 'mister'), default='all')
    parser.add_argument('--dry-run', action='store_true', help='Validate GUI input and print the command without building')
    opts = parser.parse_args(argv)
    try:
        rom = valid_file(opts.rom, 'Arcade ROM archive', ('.zip', '.7z'))
        nsp = valid_file(opts.nsp, 'USA base NSP', ('.nsp',))
        keys = valid_file(opts.keys, 'Switch keys file')
        if not (HERE / 'apply.py').is_file() or not (HERE / 'kit.json').is_file():
            raise ValueError('Kit incomplete: apply.py or kit.json is missing.')
        root = Path(opts.output_root).expanduser().resolve()
        if root.exists() and not root.is_dir():
            raise ValueError(f'Output location is a file, not a folder: {root}')
        if root == HERE or HERE in root.parents:
            raise ValueError('Choose an output location outside the kit folder.')
        if any(root == f or f in root.parents for f in (rom, nsp, keys)):
            raise ValueError('Output location cannot be inside a supplied input file.')
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        token = uuid.uuid4().hex[:6]
        destination = root / f'USF2_US_{stamp}_{token}'
        work = root / '_USF2_private_work' / f'{stamp}_{token}'
        command = build_command(rom, nsp, keys, destination, work, opts.platform)
        if opts.dry_run:
            print('DRY RUN: command construction succeeded.')
            print(' '.join(shlex.quote(arg) for arg in command))
            return 0
        root.mkdir(parents=True, exist_ok=True)
        print('USF2 BACKPORT RC2 | BUILD STARTED', flush=True)
        print('ROM archive :', rom.name, flush=True)
        print('USA NSP     :', nsp.name, flush=True)
        print('Target      :', opts.platform, flush=True)
        print('Output      :', destination, flush=True)
        print('Private work:', work, flush=True)
        print('Note: the kit requires Git, CMake, and a C/C++ toolchain for the pinned native tools.', flush=True)
        print('=' * 60, flush=True)
        # Explicit inherited stdout/stderr: the Windows frontend sends both to its live log.
        code = subprocess.call(command, cwd=HERE)
        print('=' * 60, flush=True)
        if code:
            print(f'BUILD FAILED (exit code {code}). See log for details.', flush=True)
            return code if code > 0 else 1
        if not (destination / 'verification.json').is_file():
            print('ERROR: Builder exited successfully but did not publish verification.json.', flush=True)
            return 3
        print('BUILD VERIFIED BY KIT:', destination, flush=True)
        return 0
    except (ValueError, OSError) as error:
        print('ERROR:', error, file=sys.stderr, flush=True)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
