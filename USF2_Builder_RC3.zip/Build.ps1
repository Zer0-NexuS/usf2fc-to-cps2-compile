# Background build process. Output and errors are redirected by the GUI to a live log.
param([Parameter(Mandatory=$true)][string]$Request)
$ErrorActionPreference = 'Stop'
try {
    $root = $PSScriptRoot
    $config = Get-Content -LiteralPath $Request -Raw -Encoding UTF8 | ConvertFrom-Json
    $platform = [string]$config.platform
    if ($platform -notin @('all', 'mame', 'hbmame', 'mister')) { throw 'Invalid target selection.' }
    Write-Output 'USF2 RC3 DROP BUILDER'
    Write-Output 'Preparing the portable development tools. First-time downloads require internet access.'
    # Tool setup edits PATH only in this temporary PowerShell child process.
    . (Join-Path $root 'Setup_Toolchain.ps1') -Platform $platform
    $python = Join-Path $root '_portable_tools\python\python.exe'
    $args = @('-u', (Join-Path $root 'frontend_runner.py'),
        '--rom', [string]$config.rom, '--nsp', [string]$config.nsp,
        '--keys', [string]$config.keys, '--output-root', [string]$config.output,
        '--platform', $platform)
    Write-Output '[BUILD] Starting reconstruction with the unmodified RC3 kit.'
    & $python @args
    if ($LASTEXITCODE -ne 0) { exit [int]$LASTEXITCODE }
    Write-Output '[BUILD] Reconstruction and published verification checks finished.'
    exit 0
} catch {
    Write-Output ('ERROR: ' + $_.Exception.Message)
    Write-Output ('DETAILS: ' + $_.ScriptStackTrace)
    exit 1
}
