# Portable dependency provisioning for the unmodified USF2 rc2 kit.
# Installs only into _portable_tools beside this script. No admin rights required.
param(
    [ValidateSet('all', 'mame', 'hbmame', 'mister')]
    [string]$Platform = 'all'
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$portable = Join-Path $PSScriptRoot '_portable_tools'
$downloads = Join-Path $portable 'downloads'
New-Item -ItemType Directory -Path $downloads -Force | Out-Null

function Say([string]$Message) {
    Write-Output "[TOOLS] $Message"
}
function Download-Tool([string]$Uri, [string]$Destination) {
    if (Test-Path -LiteralPath $Destination -PathType Leaf) { return }
    Say "Downloading $([IO.Path]::GetFileName($Destination)) (first run; this may take several minutes)..."
    $partial = "$Destination.part"
    if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial -Force }
    try {
        Invoke-WebRequest -Uri $Uri -UseBasicParsing -OutFile $partial -TimeoutSec 3600 -Headers @{ 'User-Agent' = 'USF2-portable-builder' }
        if ((Get-Item -LiteralPath $partial).Length -lt 10000) {
            throw "Unexpectedly small download: $Uri"
        }
        Move-Item -LiteralPath $partial -Destination $Destination -Force
    } finally {
        if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial -Force }
    }
}
function Check-Sha256([string]$Path, [string]$Expected) {
    $got = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($got -ne $Expected.ToLowerInvariant()) {
        Remove-Item -LiteralPath $Path -Force
        throw "Downloaded tool checksum mismatch. Stopped rather than executing $Path."
    }
}
function Pick-Exe([string]$Directory, [string]$Name) {
    Get-ChildItem -LiteralPath $Directory -Filter $Name -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
}

# Python is the official 64-bit Windows embeddable distribution, not system Python.
$pythonDir = Join-Path $portable 'python'
$pythonExe = Join-Path $pythonDir 'python.exe'
if (-not (Test-Path -LiteralPath $pythonExe)) {
    $archive = Join-Path $downloads 'python-3.11.9-embed-amd64.zip'
    Download-Tool 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip' $archive
    New-Item -ItemType Directory -Path $pythonDir -Force | Out-Null
    Say 'Extracting portable Python 3.11...'
    Expand-Archive -LiteralPath $archive -DestinationPath $pythonDir -Force
    Remove-Item -LiteralPath $archive -Force
}
if (-not (Test-Path -LiteralPath $pythonExe)) { throw 'Python extraction did not produce python.exe.' }
$pth = Join-Path $pythonDir 'python311._pth'
# The official embeddable Python runs in isolated sys.path mode when its ._pth
# file is present. Even when apply.py is invoked by absolute path, its directory
# is NOT automatically importable. The kit's nsp.py, payload.py, etc. are beside
# apply.py, so add that folder relative to the portable interpreter directory.
# This entry remains portable if the entire builder folder is moved/renamed:
#   USF2_Drop_Builder/_portable_tools/python/python311._pth -> ..\.. -> kit root.
if (-not (Test-Path -LiteralPath $pth -PathType Leaf)) {
    throw 'Embedded Python path configuration (python311._pth) is missing.'
}
$pthLines = @(Get-Content -LiteralPath $pth)
$normalizedPthLines = @($pthLines | ForEach-Object { $_.Trim() })
if ($normalizedPthLines -notcontains 'import site') {
    $pthLines = @($pthLines | ForEach-Object {
        if ($_.Trim() -eq '#import site') { 'import site' } else { $_ }
    })
}
if (@($pthLines | ForEach-Object { $_.Trim() }) -notcontains 'import site') {
    $pthLines += 'import site'
}
# Ensure existing installations get the correction without redownloading Python.
if (@($pthLines | ForEach-Object { $_.Trim() }) -notcontains '..\..') {
    $pthLines = @('..\..') + $pthLines
}
Set-Content -LiteralPath $pth -Value $pthLines -Encoding ASCII

# Fail fast if the modules are not visible, instead of failing after all tools
# have initialized and the user has pressed BUILD.
& $pythonExe -c 'import pathlib, sys, nsp, payload, rom_sources, policy, stock_mame; kit = pathlib.Path(sys.executable).resolve().parents[2]; assert pathlib.Path(nsp.__file__).resolve().parent == kit, "Wrong nsp.py import path"; print("[TOOLS] RC2 kit module imports: ready.")'
if ($LASTEXITCODE -ne 0) { throw 'The portable Python cannot import the bundled RC2 kit modules. Check python311._pth and the kit folder.' }
Say 'Python: ready.'

# A single WinLibs archive includes GCC, G++, CMake, Ninja, binutils and make.
# Pin an official source release and verify the publisher's stated SHA-256.
$winlibs = Join-Path $portable 'winlibs'
$gcc = Join-Path $winlibs 'mingw64\bin\gcc.exe'
$cmake = Join-Path $winlibs 'mingw64\bin\cmake.exe'
if (-not ((Test-Path -LiteralPath $gcc) -and (Test-Path -LiteralPath $cmake))) {
    $archive = Join-Path $downloads 'winlibs-x86_64-gcc-16.2.0-ucrt.zip'
    $url = 'https://github.com/brechtsanders/winlibs_mingw/releases/download/16.2.0posix-14.0.0-ucrt-r1/winlibs-x86_64-posix-seh-gcc-16.2.0-mingw-w64ucrt-14.0.0-r1.zip'
    Download-Tool $url $archive
    Check-Sha256 $archive 'c1f52294597c0b73786b2a78eb5d176d89226d2f21875eab75e783a8b1cefcc4'
    Say 'Extracting portable compiler, CMake and Ninja (approximately 1 GB on disk)...'
    New-Item -ItemType Directory -Path $winlibs -Force | Out-Null
    Expand-Archive -LiteralPath $archive -DestinationPath $winlibs -Force
    Remove-Item -LiteralPath $archive -Force
}
if (-not ((Test-Path -LiteralPath $gcc) -and (Test-Path -LiteralPath $cmake))) {
    throw 'The portable WinLibs archive did not contain mingw64/bin/gcc.exe and cmake.exe.'
}
$env:PATH = "$(Join-Path $winlibs 'mingw64\bin');$env:PATH"
Say 'GCC + CMake + Ninja: ready.'

# Pinned official MinGit is sufficient for the source checkouts and is much smaller
# than full PortableGit. Verify the published SHA256 before unpacking.
$gitDir = Join-Path $portable 'MinGit'
$gitExe = Join-Path $gitDir 'cmd\git.exe'
if (-not (Test-Path -LiteralPath $gitExe)) {
    $archive = Join-Path $downloads 'MinGit-2.56.0.2-64-bit.zip'
    $url = 'https://github.com/git-for-windows/git/releases/download/v2.56.0.windows.2/MinGit-2.56.0.2-64-bit.zip'
    Download-Tool $url $archive
    Check-Sha256 $archive 'ab2543fea7eebdc8476b63af2ff8acec10fce72fc9f72a40c9123df94c6ac1ae'
    New-Item -ItemType Directory -Path $gitDir -Force | Out-Null
    Say 'Extracting verified portable Git...'
    Expand-Archive -LiteralPath $archive -DestinationPath $gitDir -Force
    Remove-Item -LiteralPath $archive -Force
}
if (-not (Test-Path -LiteralPath $gitExe)) { throw 'MinGit extraction did not produce cmd/git.exe.' }
$env:PATH = "$(Join-Path $gitDir 'cmd');$(Join-Path $gitDir 'ucrt64\bin');$env:PATH"
# Fix 4: Some machines have an installed Git configuration referencing a stale
# C:/Program Files/Git/.../ca-bundle.crt. Portable MinGit inherits that config
# and cannot load that nonexistent file. Use the native Windows certificate
# store with the secure Schannel TLS backend for this builder process only.
# These Git environment config entries propagate to Python's nested Git clones,
# and override system/global config without changing either one permanently.
# Keep certificate verification ON; never use http.sslVerify=false.
$env:GIT_CONFIG_COUNT = '3'
$env:GIT_CONFIG_KEY_0 = 'http.sslBackend'
$env:GIT_CONFIG_VALUE_0 = 'schannel'
$env:GIT_CONFIG_KEY_1 = 'http.schannelUseSSLCAInfo'
$env:GIT_CONFIG_VALUE_1 = 'false'
$env:GIT_CONFIG_KEY_2 = 'http.sslVerify'
$env:GIT_CONFIG_VALUE_2 = 'true'
# Avoid explicit Git CA environment overrides inherited from unrelated installs.
foreach ($setting in @('GIT_SSL_CAINFO', 'GIT_SSL_CAPATH', 'GIT_SSL_NO_VERIFY')) {
    Remove-Item -Path ("Env:" + $setting) -ErrorAction SilentlyContinue
}
# Fail fast if the portable git doesn't accept the secure configuration.
$gitBackend = & $gitExe config --get http.sslBackend
if ($LASTEXITCODE -ne 0 -or $gitBackend -ne 'schannel') {
    throw 'Portable Git TLS backend could not be set to Windows Schannel.'
}
$gitVerified = & $gitExe config --bool --get http.sslVerify
if ($LASTEXITCODE -ne 0 -or $gitVerified -ne 'true') {
    throw 'Portable Git certificate verification could not be enabled.'
}
$gitUseCA = & $gitExe config --bool --get http.schannelUseSSLCAInfo
if ($LASTEXITCODE -ne 0 -or $gitUseCA -ne 'false') {
    throw 'Portable Git was not configured to use the Windows certificate store.'
}
Say 'Portable Git: ready (Windows trusted certificates; TLS verification enabled).'

# The MiSTer music route needs ffmpeg for ADX and may need NumPy on kit updates.
# Neither is required to build stock MAME or HBMAME outputs.
if ($Platform -eq 'all' -or $Platform -eq 'mister') {
    $ffmpegDir = Join-Path $portable 'ffmpeg'
    $ffmpegExe = Pick-Exe $ffmpegDir 'ffmpeg.exe'
    if (-not $ffmpegExe) {
        $archive = Join-Path $downloads 'ffmpeg-release-essentials.zip'
        Download-Tool 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' $archive
        New-Item -ItemType Directory -Path $ffmpegDir -Force | Out-Null
        Say 'Extracting portable FFmpeg...'
        Expand-Archive -LiteralPath $archive -DestinationPath $ffmpegDir -Force
        Remove-Item -LiteralPath $archive -Force
        $ffmpegExe = Pick-Exe $ffmpegDir 'ffmpeg.exe'
    }
    if (-not $ffmpegExe) { throw 'FFmpeg extraction did not produce ffmpeg.exe.' }
    $env:PATH = "$(Split-Path -Parent $ffmpegExe);$env:PATH"
    $env:CPSPLUS_FFMPEG = $ffmpegExe
    Say 'FFmpeg: ready.'
    # The rc2 code currently uses stdlib, but the kit documentation requests NumPy.
    # A missing optional package must NOT emit native stderr here: in Windows
    # PowerShell 5.1, $ErrorActionPreference='Stop' treats it as a fatal error.
    # An importlib spec check exits quietly with 1 when NumPy is absent.
    & $pythonExe -c 'import importlib.util,sys; sys.exit(0 if importlib.util.find_spec("numpy") else 1)'
    if ($LASTEXITCODE -ne 0) {
        $getpip = Join-Path $downloads 'get-pip.py'
        Download-Tool 'https://bootstrap.pypa.io/get-pip.py' $getpip
        Say 'Setting up portable Python packages...'
        & $pythonExe $getpip --no-warn-script-location
        if ($LASTEXITCODE -ne 0) { throw 'Portable pip setup failed.' }
        & $pythonExe -m pip install --disable-pip-version-check --no-warn-script-location --only-binary=:all: numpy
        if ($LASTEXITCODE -ne 0) { throw 'Portable NumPy setup failed.' }
        Remove-Item -LiteralPath $getpip -Force
    }
    Say 'Python audio dependencies: ready.'
}
& $pythonExe --version
if ($LASTEXITCODE -ne 0) { throw 'Portable Python failed its launch check.' }
& $gcc --version | Select-Object -First 1
& $cmake --version | Select-Object -First 1
& $gitExe --version
Say 'Portable toolchain is ready. No system-wide installation was performed.'
