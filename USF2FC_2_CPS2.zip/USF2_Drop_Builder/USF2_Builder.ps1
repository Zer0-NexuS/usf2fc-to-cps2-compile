# USF2 RC2 | four-field Windows drag-and-drop front end.
# Requires only the Windows built-in PowerShell 5.1 and .NET WinForms UI.
# This file lives beside the unmodified RC2 kit and Build.ps1.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$null = [System.Text.Encoding]::UTF8

$bg = [System.Drawing.Color]::FromArgb(18, 23, 32)
$panel = [System.Drawing.Color]::FromArgb(28, 35, 47)
$edge = [System.Drawing.Color]::FromArgb(63, 77, 95)
$fg = [System.Drawing.Color]::FromArgb(239, 245, 250)
$muted = [System.Drawing.Color]::FromArgb(163, 178, 195)
$accent = [System.Drawing.Color]::FromArgb(63, 214, 190)
$white = [System.Drawing.Color]::White
$font = New-Object System.Drawing.Font('Segoe UI', 10)
$small = New-Object System.Drawing.Font('Segoe UI', 9)
$titleFont = New-Object System.Drawing.Font('Segoe UI Semibold', 21, [System.Drawing.FontStyle]::Bold)

$form = New-Object System.Windows.Forms.Form
$form.Text = 'USF2 | Image Builder'
$form.ClientSize = New-Object System.Drawing.Size(735, 720)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $bg
$form.ForeColor = $fg
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.MinimumSize = $form.Size
$form.Font = $font

function Add-Label([string]$s,[int]$x,[int]$y,[int]$w,[int]$h,[System.Drawing.Font]$f,[System.Drawing.Color]$color) {
    $l = New-Object System.Windows.Forms.Label
    $l.Location = New-Object System.Drawing.Point($x,$y)
    $l.Size = New-Object System.Drawing.Size($w,$h)
    $l.Text = $s
    $l.ForeColor = $color
    $l.Font = $f
    $form.Controls.Add($l)
    return $l
}
function Add-Button([string]$text,[int]$x,[int]$y,[int]$w,[int]$h,[bool]$primary) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x,$y)
    $b.Size = New-Object System.Drawing.Size($w,$h)
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 1
    $b.UseVisualStyleBackColor = $false
    if ($primary) {
        $b.BackColor = $accent
        $b.ForeColor = [System.Drawing.Color]::FromArgb(14,28,35)
        $b.FlatAppearance.BorderColor = $accent
        $b.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10, [System.Drawing.FontStyle]::Bold)
    } else {
        $b.BackColor = $panel
        $b.ForeColor = $fg
        $b.FlatAppearance.BorderColor = $edge
    }
    $form.Controls.Add($b)
    return $b
}

Add-Label 'USF2  /  IMAGE BUILDER' 23 16 650 47 $titleFont $fg | Out-Null
Add-Label 'Four inputs. Drop your files, select a build target, and press BUILD.' 25 66 676 25 $font $muted | Out-Null

function Add-DropSlot([string]$heading,[string]$placeholder,[int]$y,[bool]$isFolder,[string]$filter) {
    Add-Label $heading 25 $y 670 23 $font $fg | Out-Null
    $t = New-Object System.Windows.Forms.TextBox
    $t.Location = New-Object System.Drawing.Point(25,($y + 26))
    $t.Size = New-Object System.Drawing.Size(576,34)
    $t.Font = $font
    $t.BackColor = $panel
    $t.ForeColor = $fg
    $t.BorderStyle = 'FixedSingle'
    $t.AllowDrop = $true
    $t.Text = ''
    $t.Tag = $placeholder
    $t.Add_DragEnter({
        param($source,$event)
        if ($event.Data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop)) {
            $event.Effect = [System.Windows.Forms.DragDropEffects]::Copy
        } else { $event.Effect = [System.Windows.Forms.DragDropEffects]::None }
    })
    $t.Add_DragDrop({
        param($source,$event)
        $paths = [string[]]$event.Data.GetData([System.Windows.Forms.DataFormats]::FileDrop)
        if ($paths.Count -ge 1) { $source.Text = $paths[0] }
    })
    $form.Controls.Add($t)
    $b = Add-Button 'Browse...' 612 ($y + 25) 98 30 $false
    $selectFolder = $isFolder
    $selectedFilter = $filter
    $b.Add_Click(({ 
        if ($selectFolder) {
            $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $dialog.Description = 'Select or create the output folder'
            $dialog.ShowNewFolderButton = $true
            if ($t.Text.Trim() -and [IO.Directory]::Exists($t.Text.Trim())) { $dialog.SelectedPath = $t.Text.Trim() }
            if ($dialog.ShowDialog($form) -eq 'OK') { $t.Text = $dialog.SelectedPath }
            $dialog.Dispose()
        } else {
            $dialog = New-Object System.Windows.Forms.OpenFileDialog
            $dialog.Title = $heading
            $dialog.Filter = $selectedFilter
            $dialog.CheckFileExists = $true
            if ($dialog.ShowDialog($form) -eq 'OK') { $t.Text = $dialog.FileName }
            $dialog.Dispose()
        }
    }).GetNewClosure())
    Add-Label $placeholder 26 ($y + 63) 660 20 $small $muted | Out-Null
    return $t
}

$rom = Add-DropSlot '1   CPS2 ROM ARCHIVE' 'Drop ssf2t.zip, ssf2xj.zip, or your complete compatible ROM archive' 106 $false 'ROM archives (*.zip;*.7z)|*.zip;*.7z|All files (*.*)|*.*'
$nsp = Add-DropSlot '2   USA SWITCH NSP' 'Drop your matching USF2 USA base .nsp (not an update NSP)' 196 $false 'Switch package (*.nsp)|*.nsp|All files (*.*)|*.*'
$keys = Add-DropSlot '3   KEYS FILE' 'Drop your own prod.keys (never included in this package)' 286 $false 'Switch keys (prod.keys;*.keys;*.txt)|prod.keys;*.keys;*.txt|All files (*.*)|*.*'
$output = Add-DropSlot '4   OUTPUT FOLDER' 'Choose a folder for your verified finished build' 376 $true ''
$output.Text = Join-Path ([Environment]::GetFolderPath('Desktop')) 'USF2_Builds'

Add-Label 'BUILD TARGET' 25 468 132 26 $font $fg | Out-Null
$target = New-Object System.Windows.Forms.ComboBox
$target.Location = New-Object System.Drawing.Point(155,465)
$target.Size = New-Object System.Drawing.Size(218,30)
$target.Font = $font
$target.DropDownStyle = 'DropDownList'
$target.BackColor = $panel
$target.ForeColor = $fg
[void]$target.Items.Add('All  (MAME + HBMAME + MiSTer)')
[void]$target.Items.Add('MAME only  (fastest setup)')
[void]$target.Items.Add('HBMAME only')
[void]$target.Items.Add('MiSTer only')
$target.SelectedIndex = 0
$form.Controls.Add($target)

$start = Add-Button 'BUILD IMAGE' 394 461 185 42 $true
$cancel = Add-Button 'CANCEL' 588 461 122 42 $false
$cancel.Enabled = $false
$status = Add-Label 'Ready. No inputs have been modified.' 25 511 685 24 $small $muted

$log = New-Object System.Windows.Forms.TextBox
$log.Location = New-Object System.Drawing.Point(25,540)
$log.Size = New-Object System.Drawing.Size(685,127)
$log.Multiline = $true
$log.ReadOnly = $true
$log.ScrollBars = 'Vertical'
$log.WordWrap = $false
$log.BackColor = [System.Drawing.Color]::FromArgb(12,17,25)
$log.ForeColor = [System.Drawing.Color]::FromArgb(176,232,220)
$log.Font = New-Object System.Drawing.Font('Consolas', 9)
$log.Text = "Waiting for your inputs...`r`n"
$form.Controls.Add($log)
$open = Add-Button 'OPEN OUTPUT FOLDER' 25 679 206 30 $false
$open.Add_Click({
    $dir = $output.Text.Trim()
    if ([IO.Directory]::Exists($dir)) { [System.Diagnostics.Process]::Start('explorer.exe', ('"' + $dir + '"')) | Out-Null }
    else { [System.Windows.Forms.MessageBox]::Show('Output folder does not exist yet.','USF2 Builder','OK','Information') | Out-Null }
})
Add-Label 'Windows 10 / 11  |  local processing  |  no keys saved' 324 681 390 26 $small $muted | Out-Null

$script:proc = $null
$script:logfile = $null
$script:offset = 0L
$script:pendingLog = ''
$script:requestPath = $null
$script:builtPath = $null
$script:startedAt = $null
$script:closing = $false
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 350
function Append-Log([string]$message) {
    if (!$message) { return }
    $log.AppendText($message)
    if ($log.TextLength -gt 200000) { $log.Text = $log.Text.Substring($log.TextLength - 125000) }
}
function Drain-Log {
    if (!$script:logfile -or ![IO.File]::Exists($script:logfile)) { return }
    try {
        $fs = [IO.File]::Open($script:logfile, [IO.FileMode]::Open, [IO.FileAccess]::Read, ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
        try {
            if ($script:offset -gt $fs.Length) { $script:offset = 0L }
            if ($fs.Length -gt $script:offset) {
                $fs.Position = $script:offset
                $reader = [System.IO.StreamReader]::new($fs, [System.Text.Encoding]::UTF8, $true, 4096, $true)
                try { $delta = $reader.ReadToEnd(); $script:offset = $fs.Position } finally { $reader.Dispose() }
                Append-Log $delta
            }
        } finally { $fs.Dispose() }
    } catch { } # Another process may be replacing the log briefly.
}
function Set-Idle {
    $start.Enabled = $true
    $cancel.Enabled = $false
    $target.Enabled = $true
    $timer.Stop()
    if ($script:requestPath -and [IO.File]::Exists($script:requestPath)) {
        Remove-Item -LiteralPath $script:requestPath -Force -ErrorAction SilentlyContinue
    }
    $script:requestPath = $null
}
$timer.Add_Tick({
    Drain-Log
    if ($script:proc -and $script:proc.HasExited) {
        Drain-Log
        $exitCode = $script:proc.ExitCode
        $script:proc.Dispose()
        $script:proc = $null
        if ($exitCode -eq 0) {
            $status.Text = 'Build completed successfully. Check the output folder.'
            $status.ForeColor = $accent
            Append-Log "`r`nSUCCESS. The kit confirmed its output verification.`r`n"
        } else {
            $status.Text = "Build failed or was cancelled (exit $exitCode). See the log."
            $status.ForeColor = [System.Drawing.Color]::FromArgb(255,180,130)
            Append-Log "`r`nBuild exited with code $exitCode. See details above.`r`n"
        }
        Set-Idle
    }
})

$start.Add_Click({
    $inputRom = $rom.Text.Trim().Trim('"')
    $inputNsp = $nsp.Text.Trim().Trim('"')
    $inputKeys = $keys.Text.Trim().Trim('"')
    $outDir = $output.Text.Trim().Trim('"')
    $errorText = $null
    if (![IO.File]::Exists($inputRom)) { $errorText = 'Select the ROM ZIP / 7z archive.' }
    elseif ([IO.Path]::GetExtension($inputRom).ToLowerInvariant() -notin @('.zip','.7z')) { $errorText = 'The ROM archive must be ZIP or 7z.' }
    elseif (![IO.File]::Exists($inputNsp) -or [IO.Path]::GetExtension($inputNsp).ToLowerInvariant() -ne '.nsp') { $errorText = 'Select the USA base .nsp file.' }
    elseif (![IO.File]::Exists($inputKeys)) { $errorText = 'Select your own prod.keys file.' }
    elseif (!$outDir) { $errorText = 'Select an output directory.' }
    elseif (![IO.File]::Exists((Join-Path $root 'apply.py')) -or ![IO.File]::Exists((Join-Path $root 'kit.json'))) { $errorText = 'The bundled RC2 kit is incomplete.' }
    else {
        try {
            $rootAbs = [IO.Path]::GetFullPath($root).TrimEnd('\','/')
            $outAbs = [IO.Path]::GetFullPath($outDir).TrimEnd('\','/')
            if ($outAbs.Equals($rootAbs,[StringComparison]::OrdinalIgnoreCase) -or $outAbs.StartsWith($rootAbs+'\',[StringComparison]::OrdinalIgnoreCase)) {
                $errorText = 'Choose an output folder outside the extracted builder folder.'
            }
        } catch { $errorText = 'Invalid output directory.' }
    }
    if ($errorText) { [System.Windows.Forms.MessageBox]::Show($errorText,'Input needed','OK','Warning') | Out-Null; return }
    $platform = @('all','mame','hbmame','mister')[$target.SelectedIndex]
    $script:requestPath = Join-Path ([IO.Path]::GetTempPath()) ('usf2_request_'+[Guid]::NewGuid().ToString('N')+'.json')
    $script:logfile = Join-Path ([IO.Path]::GetTempPath()) ('usf2_build_'+[Guid]::NewGuid().ToString('N')+'.log')
    $script:offset = 0L
    $obj = @{rom=[IO.Path]::GetFullPath($inputRom);nsp=[IO.Path]::GetFullPath($inputNsp);keys=[IO.Path]::GetFullPath($inputKeys);output=$outAbs;platform=$platform}
    [IO.File]::WriteAllText($script:requestPath,($obj | ConvertTo-Json -Compress),[System.Text.Encoding]::UTF8)
    $log.Text = "Starting USF2 $platform build...`r`nPortable tools will download into _portable_tools on first use.`r`n`r`n"
    $script:startedAt = Get-Date
    $status.Text = 'Building... first-time tool setup may take several minutes.'
    $status.ForeColor = $accent
    $start.Enabled = $false
    $cancel.Enabled = $true
    $target.Enabled = $false
    # cmd.exe redirects both stdout and stderr into one UTF-8-readable stream on disk.
    # Input paths are passed in the request JSON, not interpolated into a shell command.
    $wrapper = Join-Path $root 'Run_Worker.cmd'
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = 'cmd.exe'
        $psi.Arguments = '/d /s /c ""' + $wrapper + '" "' + $script:requestPath + '" "' + $script:logfile + '""'
        $psi.WorkingDirectory = $root
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $script:proc = [System.Diagnostics.Process]::Start($psi)
        if (!$script:proc) { throw 'Worker process did not start.' }
        $timer.Start()
    } catch {
        Append-Log "ERROR: $($_.Exception.Message)`r`n"
        $status.Text = 'Could not start the build process.'
        Set-Idle
    }
})
$cancel.Add_Click({
    if (!$script:proc -or $script:proc.HasExited) { return }
    if ([System.Windows.Forms.MessageBox]::Show('Stop this build and its child tools? The original inputs will not be changed.','Cancel build','YesNo','Question') -ne 'Yes') { return }
    try {
        $pidToStop = $script:proc.Id
        # Kill the process tree, including CMake/compilers spawned by the builder.
        $k = Start-Process -FilePath 'taskkill.exe' -ArgumentList @('/PID',[string]$pidToStop,'/T','/F') -Wait -PassThru -WindowStyle Hidden
        Append-Log "`r`nCANCEL requested. taskkill exit: $($k.ExitCode)`r`n"
    } catch { Append-Log "`r`nUnable to cancel cleanly: $($_.Exception.Message)`r`n" }
})
$form.Add_FormClosing({
    param($sender,$eventArgs)
    if ($script:proc -and !$script:proc.HasExited) {
        [System.Windows.Forms.MessageBox]::Show('Cancel the current build before closing the window.','Build running','OK','Information') | Out-Null
        $eventArgs.Cancel = $true
    }
})
[void]$form.ShowDialog()
$form.Dispose()
