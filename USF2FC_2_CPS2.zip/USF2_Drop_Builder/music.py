#!/usr/bin/env python3
"""Rebuild the USF2 CPS+ arrangement from owned NSP music; no pack-input shortcut."""
import argparse
import json
from pathlib import Path
import sys
from nsp import authenticate, file_sha, toolset
from payload import require

HERE = Path(__file__).resolve().parent


def build(nsp, keys, pin, out, work, tools_work=None):
    authenticate(nsp, pin)
    require(Path(keys).is_file(), 'Supply your own Switch prod.keys')
    sys.path.insert(0, str(HERE/'sound'))
    from pack import build_usf2_remix as source
    from build_pack import adapt
    # Regional adapters change only authenticated container identities. The
    # final common CPK hash checks every track, loop and trigger independently.
    source.EXPECTED_NSP_SHA256 = pin['nsp_sha256']
    source.TICKET_NAME = pin['ticket_name']
    source.PROGRAM_NAME = pin['program_name']
    source.PROGRAM_SHA256 = pin['program_sha256']
    work = Path(work); work.mkdir(parents=True, exist_ok=True)
    source.switch_tools = lambda _root:toolset(tools_work or work/'source')
    original = work/'original.cpk'
    source.build(Path(nsp).resolve(), Path(keys).resolve(), out=original,
                 work=work/'build', scratch=work/'extract')
    commands = json.loads((HERE/'sound/music_commands.json').read_text())
    adapt(original, Path(out), commands)
    expected = json.loads((HERE/'kit.json').read_text())['cpk_sha256']
    require(file_sha(out) == expected, 'Rebuilt CPK differs from the selected arrangement')
    original.unlink(); Path(str(original)+'.json').unlink()
    return Path(out)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--nsp', type=Path, required=True); p.add_argument('--keys', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True); p.add_argument('--work', type=Path, required=True)
    a = p.parse_args(); pins = json.loads((HERE/'kit.json').read_text())['nsp']
    digest = file_sha(a.nsp)
    found = [v for v in pins.values() if v['nsp_sha256'] == digest]
    require(len(found) == 1, 'Unsupported base NSP')
    require(not a.out.exists(), 'Choose a fresh CPK output')
    build(a.nsp, a.keys, found[0], a.out, a.work)
    print('PASS exact NSP-derived CPS+ arrangement')
