@echo off
setlocal
REM This worker merges standard output and errors into the log read by the GUI.
REM %1: JSON request, %2: logfile.
if "%~2"=="" exit /b 2
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build.ps1" -Request "%~1" > "%~2" 2>&1
exit /b %ERRORLEVEL%
