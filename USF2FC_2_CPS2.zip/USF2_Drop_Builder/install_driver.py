#!/usr/bin/env python3
"""Install the kit's exact set definitions in a clean MAME/HBMAME CPS-2 driver."""
import argparse
from pathlib import Path
import re
from payload import require

BEGIN = '// BEGIN USF2 RECONSTRUCTION KIT SETS'
END = '// END USF2 RECONSTRUCTION KIT SETS'


def install(driver, definitions, check=False, list_path=None):
    body = '\n'.join(p.read_text() for p in sorted(definitions.glob('*.cpp.inc')))
    require(body.count('ROM_START(') == 4, 'Complete four-set driver definitions required')
    text = driver.read_text()
    block = BEGIN + '\n' + body + '\n' + END
    installed = BEGIN in text
    if installed:
        require(text.count(BEGIN) == text.count(END) == 1 and
                text[text.index(BEGIN):text.index(END)+len(END)] == block,
                'An installed USF2 definition differs; use a clean driver')
    names = re.findall(r'ROM_START\(\s*(\w+)', body)
    if not installed:
        require(all(not re.search(r'ROM_START\(\s*' + re.escape(n) + r'\s*\)', text)
                    for n in names), 'A different definition already owns a USF2 set name')
        require('cps2' in text and not check, 'Definitions are not installed in this driver')
        text = text.rstrip() + '\n\n' + block + '\n'
    listing = None
    if list_path is not None:
        listing = list_path.read_text()
        list_block = BEGIN+'\n'+'\n'.join(names)+'\n'+END
        if BEGIN in listing:
            require(listing.count(BEGIN) == listing.count(END) == 1 and
                listing[listing.index(BEGIN):listing.index(END)+len(END)] == list_block,
                'Installed USF2 driver list differs')
        else:
            require(not check and all(not re.search(r'^'+n+r'\s*(?://.*)?$',listing,re.M) for n in names),
                    'Driver list is missing or already contains conflicting USF2 entries')
            sources = list(re.finditer(r'^@source:(\S+)\s*$',listing,re.M))
            matches = [i for i,m in enumerate(sources) if Path(m.group(1)).name == driver.name]
            require(len(matches) == 1, 'CPS-2 driver source is absent or duplicated in the list')
            i = matches[0]; at = sources[i+1].start() if i+1 < len(sources) else len(listing)
            listing = listing[:at].rstrip()+'\n'+list_block+'\n\n'+listing[at:]
    if not check:
        driver.write_text(text)
        if list_path is not None:list_path.write_text(listing)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--driver', type=Path, required=True)
    p.add_argument('--list', dest='list_path', type=Path, required=True,
                   help='src/mame/mame.lst or src/hbmame/hbmame.lst')
    p.add_argument('--check', action='store_true'); a = p.parse_args()
    install(a.driver, Path(__file__).resolve().parent/'definitions', a.check, a.list_path)
    print('PASS USF2 CPS-2 driver definitions')
