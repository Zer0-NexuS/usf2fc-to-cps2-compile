#!/usr/bin/env python3
"""Build the approved USF2 arrangement with native-only OFF command aliases.

This entry point is exported with its pack/ and tools/ dependencies. Supply
owned NSP/keys to reconstruct the accepted music, or a byte-identical accepted
pack. The adaptation changes trigger rows and their CRC, never the ADX music.
"""
import argparse,hashlib,json,shutil,struct,sys,zlib
from pathlib import Path

ACCEPTED='59040e349b58193d6ffca300dd30078628e88df1266cd5ab9bb68c62272b50d6'

def package_root():
    here=Path(__file__).resolve().parent
    if (here/'pack/format.py').is_file():return here
    return here.parents[2]/'cpsplus'

def adapt(source,out,commands):
    if hashlib.sha256(source.read_bytes()).hexdigest()!=ACCEPTED:raise ValueError('Unapproved source arrangement')
    sys.path.insert(0,str(package_root()))
    from pack.format import PackReader,TriggerRow,VERB_STOP,_HDR_FIXED
    reader=PackReader(source);h=reader.header;data=bytearray(source.read_bytes());rows=[]
    for c in commands:
        alias=c+511
        if reader.triggers[alias].verb:raise ValueError('Native-only alias already has a pack owner')
        at=h.trigger_offset+alias*4;data[at:at+4]=TriggerRow(verb=VERB_STOP,suppress=0).pack();rows.append(alias)
    end=h.trigger_offset+h.trigger_rows*4;index=bytes(data[h.index_offset:h.index_offset+h.track_count*32])
    fields=list(_HDR_FIXED.unpack_from(data));fields[-2]=zlib.crc32(index,zlib.crc32(data[h.trigger_offset:end]))
    _HDR_FIXED.pack_into(data,0,*fields)
    original=source.read_bytes()
    if data[h.data_offset:]!=original[h.data_offset:]or data[h.index_offset:h.index_offset+h.track_count*32]!=original[h.index_offset:h.index_offset+h.track_count*32]:
        raise ValueError('Arrangement track data changed')
    out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);reader.close()
    final=PackReader(out)
    if final.crc_check()!=(True,True):raise ValueError('Adapted pack CRC mismatch')
    final.close()
    report=dict(status='verified_native_alias_arrangement',source_sha256=ACCEPTED,
        sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),music_commands=commands,
        native_aliases=rows,alias_verb='STOP without native suppression',ADX_track_index_and_music_bytes_exact=True,
        default_arrangement_and_loop_points_unchanged=True)
    Path(str(out)+'.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');return report

def export(destination,commands):
    source=package_root();destination.mkdir(parents=True)
    shutil.copy2(Path(__file__),destination/'build_pack.py')
    modules=('__init__','build_usf2_remix','adxcodec','ssf2_family','protocols','build_common','format')
    (destination/'pack').mkdir()
    for n in modules:shutil.copy2(source/'pack'/(n+'.py'),destination/'pack'/(n+'.py'))
    (destination/'tools').mkdir()
    for n in('setup_switch_tools.py','setup_x68k_music_tools.py','switch_opus_decode.c'):
        shutil.copy2(source/'tools'/n,destination/'tools'/n)
    (destination/'manifests').mkdir();shutil.copy2(source/'manifests/hsf2_bgm_command_map.tsv',destination/'manifests/hsf2_bgm_command_map.tsv')
    (destination/'music_commands.json').write_text(json.dumps(commands)+'\n')
    (destination/'README.txt').write_text('USF2 CPS+ arrangement builder\n\nPython 3, NumPy, FFmpeg, git, CMake and a C/C++ compiler are required.\nProvide your own extracted USA base NSP and prod.keys.\n\npython3 build_pack.py --nsp YOUR_GAME.nsp --keys YOUR_prod.keys --out usf2_arrange.cpk --work scratch\n\nAlternatively use --source-pack with the accepted SSF2-family USF2 arrangement.\nNo game, key or music data is included in this source builder.\nThe generated arrangement preserves its accepted music and loops; OFF aliases stop pack playback and allow native QSound music.\n')
