#!/usr/bin/env python3
"""Focused corrupt/wrong-source, bounded decoder and driver collision tests."""
import hashlib
from pathlib import Path
import random
import tempfile
import unittest
from unittest.mock import patch
import subprocess
import zipfile
import warnings
import verify
import payload
import install_driver
import nsp
import policy
import stock_mame


class KitTests(unittest.TestCase):
    def test_stock_mame_verifies_native_hashes_and_PCM_mirror(self):
        files={n:bytes([i])*0x80000 for i,n in enumerate(stock_mame.PROGRAM)}
        files.update({'sfx.01':b'A'*0x20000,'sfx.02':b'B'*0x20000,
                      'sfx.11m':b'C'*0x200000,'sfx.12m':b'D'*0x200000,
                      'ssf2xj.key':b'K'*20,'dl-1425.bin':b'F'*24576})
        for lane in range(4):
            for prefix,index,size in (('sfx',13,0x200000),('sfx',14,0x100000),
                                      ('sfx',21,0x100000),('usf2',29,0x400000)):
                files[f'{prefix}.{index+lane*2}m']=bytes([index+lane])*size
        with tempfile.TemporaryDirectory() as temporary:
            for region,profile,expected in (('us','usf2t4','hsf2'),('jp','usf2j4','hsf2j')):
                record=dict(region=region,members={n:dict(size=len(b),sha256=payload.sha(b))for n,b in files.items()})
                name,packed=stock_mame.repack(files,region)
                self.assertEqual(name,expected)
                path=Path(temporary)/(name+'.zip')
                stock_mame.write_zip(path,packed)
                self.assertEqual(verify.verify_stock_archive(path,profile,record),files)
                for member,offset,diagnostic in (('hs2.11m',0x400000,'mirror differs'),
                                                 (name+'.key',0,'native member differs')):
                    original=packed[member]
                    packed[member]=original[:offset]+b'X'+original[offset+1:]
                    stock_mame.write_zip(path,packed)
                    with self.assertRaisesRegex(ValueError,diagnostic):
                        verify.verify_stock_archive(path,profile,record)
                    packed[member]=original

    def test_zip_compression_independent_ROM_identity(self):
        files={'test.03':b'program data'*1000,'test.04':b'graphics data'*800}
        record={'members':{name:dict(size=len(data),sha256=payload.sha(data)) for name,data in files.items()}}
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);digests=[]
            for compression in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED):
                path=root/(str(compression)+'.zip')
                with zipfile.ZipFile(path,'w',compression=compression) as archive:
                    for name,data in files.items():archive.writestr(name,data)
                self.assertEqual(verify.verify_archive(path,record),files)
                digests.append(nsp.file_sha(path))
            self.assertNotEqual(*digests)
            for case in ('changed','extra','missing','duplicate'):
                path=root/(case+'.zip')
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore',UserWarning)
                    with zipfile.ZipFile(path,'w') as archive:
                        for name,data in files.items():
                            if case=='missing' and name=='test.04':continue
                            archive.writestr(name,b'X'+data[1:] if case=='changed' else data)
                        if case=='extra':archive.writestr('extra',b'bad')
                        if case=='duplicate':archive.writestr('test.03',files['test.03'])
                with self.assertRaises(ValueError):verify.verify_archive(path,record)

    def test_nsp_folder_extraction_and_failure_diagnostics(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);package=root/'test.nsp';package.write_bytes(b'programticket')
            keys=root/'prod.keys';keys.write_text('# synthetic test fixture\n')
            resource=b'authenticated resource fixture'*2
            for region in ('us','jp'):
                pin=dict(program_name='program.nca',ticket_name='ticket.tik',
                    program_sha256=hashlib.sha256(b'program').hexdigest(),
                    resource_path=f'/1/nativeNXx64/app/arc_{region}/mess/mess_resident.arc',
                    resource_sha256=hashlib.sha256(resource).hexdigest())
                found={'program.nca':(0,7),'ticket.tik':(7,6)}
                def extract(command,**options):
                    requested=command[command.index('-x')+1]
                    if requested.endswith('.arc'):
                        return subprocess.CompletedProcess(command,1,'','Access is denied')
                    self.assertEqual(requested,f'/1/nativeNXx64/app/arc_{region}/mess')
                    self.assertNotIn('--showkeys',command);self.assertNotIn('--verbose',command)
                    destination=Path(command[command.index('-x')+2])
                    (destination/'mess_resident.arc').write_bytes(resource)
                    return subprocess.CompletedProcess(command,0,'','')
                with patch.object(nsp,'authenticate',return_value=found), \
                     patch.object(nsp,'toolset',return_value={'nstool':root/'nstool'}), \
                     patch.object(nsp.subprocess,'run',side_effect=extract):
                    self.assertEqual(nsp.unlock(package,keys,pin,root/'work'),payload.source_key(resource))
                    with self.assertRaisesRegex(ValueError,'resource identity differs'):
                        nsp.unlock(package,keys,dict(pin,resource_sha256='0'*64),root/'work')
                with patch.object(nsp,'authenticate',return_value=found), \
                     patch.object(nsp,'toolset',return_value={'nstool':root/'nstool'}), \
                     patch.object(nsp.subprocess,'run',return_value=subprocess.CompletedProcess(
                         [],1,'AES-CTR Key: '+'ab'*16,'Access is denied')):
                    with self.assertRaises(ValueError) as caught:
                        nsp.unlock(package,keys,pin,root/'work')
                    diagnostic=str(caught.exception)
                    self.assertIn('Access is denied',diagnostic)
                    self.assertIn('0x00000001',diagnostic)
                    self.assertNotIn('ab'*16,diagnostic)
                    self.assertNotIn('check your keys',diagnostic)

    def test_shipping_platform_and_MRA_matrix(self):
        for name in ('usf2t4','usf2j4'):
            policy.check_mras(name,[])
            self.assertEqual(policy.platforms_for(name,('mame','hbmame','mister')),('mame',))
            with self.assertRaises(ValueError):
                policy.check_mras(name,[dict(arrange=False),dict(arrange=True)])
        for name in ('usf2t8','usf2j8'):
            policy.check_mras(name,[dict(arrange=True)])
            self.assertEqual(policy.platforms_for(name,('mame','hbmame','mister')),('hbmame','mister'))
            with self.assertRaises(ValueError):policy.check_mras(name,[dict(arrange=False)])

    def test_missing_media_and_bad_container(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);bad=root/'source.nsp';bad.write_bytes(b'not an NSP')
            with self.assertRaises(ValueError):nsp.entries(bad)
            with self.assertRaises(ValueError):nsp.authenticate(root/'missing.nsp',{'region':'us','nsp_sha256':'0'*64})
            with self.assertRaises(ValueError):nsp.unlock(bad,root/'missing.keys',{},root/'work')
    def test_exact_and_wrong_source(self):
        rng=random.Random(103)
        source=rng.randbytes(4096); target=source[:100]+rng.randbytes(200)+source[300:]+b'custom art'
        key=payload.source_key(b'owned resource'*20)
        wrapped,record=payload.encode(target,source,key,'us')
        self.assertEqual(payload.decode(wrapped,record,source,key),target)
        for bad_key,bad_source in ((b'X'*32,source),(key,b'X'*4096)):
            with self.assertRaises(ValueError):payload.decode(wrapped,record,bad_source,bad_key)
        with self.assertRaises(ValueError):payload.decode(wrapped[:-1],record,source,key)
        with self.assertRaises(ValueError):payload.decode(wrapped,dict(record,output_bytes=2),source,key)

    def test_no_public_digest_key_and_no_stream_reuse(self):
        resource=b'private actual source content'*20
        key=payload.source_key(resource)
        self.assertNotEqual(key,hashlib.sha256(resource).digest())
        self.assertNotEqual(payload.mask(b'A'*256,key,'us:asset1'),payload.mask(b'A'*256,key,'us:asset2'))

    def test_driver_collision(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);defs=root/'definitions';defs.mkdir();driver=root/'cps2.cpp'
            for i in range(4):(defs/(str(i)+'.cpp.inc')).write_text('ROM_START( usf2test'+str(i)+' )\nROM_END\n')
            driver.write_text('// cps2 clean\n');listing=root/'mame.lst'
            listing.write_text('@source:capcom/cps2.cpp\nssf2t\n@source:next.cpp\nnextgame\n')
            install_driver.install(driver,defs,list_path=listing)
            install_driver.install(driver,defs,True,listing)
            self.assertLess(listing.read_text().index('usf2test0'),listing.read_text().index('@source:next.cpp'))
            original=driver.read_text();driver.write_text(original.replace('usf2test0','usf2wrong'))
            with self.assertRaises(ValueError):install_driver.install(driver,defs)


if __name__=='__main__':unittest.main()
