"""Shipping matrix: MAME 4 MiB; HBMAME and the two CPS+ MRAs 8 MiB."""

def platforms_for(name, requested):
    mra_variants(name)  # Validate the complete set identity.
    supported = ('hbmame','mister') if name.endswith('8') else ('mame',)
    return tuple(p for p in requested if p in supported)

def mra_variants(name):
    if name not in ('usf2t4','usf2t8','usf2j4','usf2j8'):
        raise ValueError('Unknown USF2 profile: '+name)
    return (True,) if name.endswith('8') else ()


def check_mras(name,rows):
    if sorted(bool(r['arrange'])for r in rows)!=list(mra_variants(name)):
        raise ValueError('Unsupported or incomplete MiSTer launcher matrix: '+name)
