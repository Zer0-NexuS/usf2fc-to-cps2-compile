"""Read only declared PFS0 entries; decrypt with your keys and pinned NSTool."""
import hashlib
from pathlib import Path, PurePosixPath
import re
import struct
import subprocess
import sys
import tempfile
from payload import require, sha, source_key


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def entries(path):
    size = Path(path).stat().st_size
    with Path(path).open('rb') as stream:
        header = stream.read(16)
        require(len(header) == 16, 'Truncated NSP')
        magic, count, strings_size, reserved = struct.unpack('<4sIII', header)
        require(magic == b'PFS0' and 0 < count < 1024 and strings_size < 1024 * 1024,
                'Expected an extracted PFS0 base NSP')
        table = stream.read(count * 24); strings = stream.read(strings_size)
    require(len(table) == count * 24 and len(strings) == strings_size, 'Truncated NSP directory')
    base = 16 + count * 24 + strings_size
    result = {}; spans = []
    for i in range(count):
        offset, length, name_at, _ = struct.unpack_from('<QQII', table, i * 24)
        require(name_at < len(strings) and b'\0' in strings[name_at:], 'Invalid NSP filename')
        name = strings[name_at:].split(b'\0', 1)[0].decode('utf-8')
        require(name and Path(name).name == name and '\\' not in name and name not in result
                and offset + length <= size - base, 'Invalid NSP entry')
        result[name] = (base + offset, length); spans.append((offset, offset + length))
    spans.sort()
    require(all(a[1] <= b[0] for a, b in zip(spans, spans[1:])), 'Overlapping NSP entries')
    return result


def copy_entry(path, extent, target):
    offset, length = extent
    h = hashlib.sha256()
    with Path(path).open('rb') as source, Path(target).open('wb') as output:
        source.seek(offset)
        while length:
            block = source.read(min(length, 8 * 1024 * 1024))
            require(block, 'Truncated NSP entry')
            output.write(block); h.update(block); length -= len(block)
    return h.hexdigest()


def toolset(work, tools_source=None):
    sys.path.insert(0, str(tools_source or Path(__file__).resolve().parent / 'sound/tools'))
    import setup_switch_tools
    return setup_switch_tools.setup(Path(work) / 'switch-tools')


def authenticate(path, pin):
    require(Path(path).is_file(), 'Required base NSP is missing')
    require(file_sha(path) == pin['nsp_sha256'], 'Unsupported or changed ' + pin['region'] + ' base NSP')
    found = entries(path)
    require(pin['program_name'] in found and pin['ticket_name'] in found,
            'Required Program NCA or ticket is missing')
    return found


def unlock(path, keys, pin, work, tools_source=None):
    require(Path(keys).is_file(), 'Supply your own Switch prod.keys')
    found = authenticate(path, pin)  # Always required, including a warm tool cache.
    work = Path(work); work.mkdir(parents=True, exist_ok=True)
    tools = toolset(work, tools_source)
    with tempfile.TemporaryDirectory(prefix='source-', dir=work) as temporary:
        temp = Path(temporary)
        program = temp / pin['program_name']; ticket = temp / pin['ticket_name']
        require(copy_entry(path, found[pin['program_name']], program) == pin['program_sha256'],
                'Program NCA identity differs')
        copy_entry(path, found[pin['ticket_name']], ticket)
        destination = temp / 'resource'; destination.mkdir()
        # NSTool's single-file extraction probes the destination in a way
        # that can raise access-denied on Windows. Extract the containing
        # directory, as the music builder already does, then hash the file.
        resource_path = PurePosixPath(pin['resource_path'])
        result = subprocess.run([str(tools['nstool']), '-k', str(Path(keys).resolve()),
            '--tik', str(ticket), '-x', str(resource_path.parent), str(destination), str(program)],
            capture_output=True, text=True, encoding='utf-8', errors='replace')
        if result.returncode != 0:
            # Never enable NSTool's --showkeys/--verbose. Mask long hex values
            # defensively before surfacing default tool diagnostics.
            details = '\n'.join(part for part in (result.stdout, result.stderr) if part).strip()
            details = re.sub(r'(?i)\b[0-9a-f]{32,}\b', '[hex value omitted]', details)
            status = f'{result.returncode} (0x{result.returncode & 0xffffffff:08X})'
            raise ValueError('NSTool source extraction failed; exit code ' + status + '\n'
                             + (details[-12000:] or 'NSTool returned no diagnostic output.'))
        resource = destination / resource_path.name
        require(resource.is_file() and file_sha(resource) == pin['resource_sha256'],
                'Decrypted regional resource identity differs')
        return source_key(resource.read_bytes())
