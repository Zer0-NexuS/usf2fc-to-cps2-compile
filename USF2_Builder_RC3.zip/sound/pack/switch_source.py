"""Bounded NSP/XCI readers and content-pinned Program NCA extraction.

Only the selected Program and, for rights-managed copies, its ticket are
materialized. XCI firmware/normal partitions are never searched for game data.
Container hashes describe provenance; the complete Program hash authenticates
the input. Callers must also check their extracted resources/final outputs.
"""
from contextlib import contextmanager
import hashlib
from pathlib import Path
import re
import struct
import subprocess
import tempfile


def require(value, message):
    if not value:
        raise ValueError(message)


def file_sha(path):
    return copy_entry(path, (0, Path(path).stat().st_size))


def copy_entry(path, extent, target=None):
    offset, remaining = extent
    require(0 <= offset and 0 <= remaining and offset + remaining <= Path(path).stat().st_size,
            'Switch entry exceeds container')
    digest = hashlib.sha256()
    with Path(path).open('rb') as source:
        source.seek(offset)
        output = Path(target).open('wb') if target is not None else None
        try:
            while remaining:
                chunk = source.read(min(remaining, 8 * 1024 * 1024))
                require(chunk, 'Truncated Switch entry')
                digest.update(chunk)
                if output is not None:
                    output.write(chunk)
                remaining -= len(chunk)
        finally:
            if output is not None:
                output.close()
    return digest.hexdigest()


def _directory(stream, start, size, magic):
    require(size >= 16, 'Truncated Switch directory')
    stream.seek(start)
    header = stream.read(16)
    require(len(header) == 16, 'Truncated Switch header')
    actual, count, strings_size, _ = struct.unpack('<4sIII', header)
    record_size = 24 if magic == b'PFS0' else 64
    require(actual == magic and count < 4096 and strings_size <= 1024 * 1024,
            'Invalid Switch directory')
    header_size = 16 + count * record_size + strings_size
    require(header_size <= size, 'Switch directory exceeds partition')
    table, strings = stream.read(count * record_size), stream.read(strings_size)
    require(len(table) == count * record_size and len(strings) == strings_size,
            'Truncated Switch directory')
    result, spans = {}, []
    for i in range(count):
        offset, length, name_at = struct.unpack_from('<QQI', table, i * record_size)
        require(name_at < len(strings) and b'\0' in strings[name_at:], 'Invalid Switch filename')
        name = strings[name_at:].split(b'\0', 1)[0].decode('utf-8')
        require(name and name not in ('.', '..') and '/' not in name and '\\' not in name
                and ':' not in name and not any(ord(c) < 32 for c in name)
                and name not in result and offset + length <= size - header_size,
                'Unsafe, duplicate or out-of-bounds Switch entry')
        result[name] = (start + header_size + offset, length)
        spans.append((offset, offset + length))
    spans.sort()
    require(all(a[1] <= b[0] for a, b in zip(spans, spans[1:])), 'Overlapping Switch entries')
    return result


def entries(path):
    path = Path(path)
    require(path.is_file(), 'Required base NSP/XCI is missing')
    size = path.stat().st_size
    with path.open('rb') as stream:
        header = stream.read(0x200)
        if header[:4] == b'PFS0':
            return _directory(stream, 0, size, b'PFS0')
        require(len(header) == 0x200 and header[0x100:0x104] == b'HEAD',
                'Expected a base NSP (PFS0) or XCI (HEAD/HFS0), outside ZIP/RAR')
        root_at = struct.unpack_from('<Q', header, 0x130)[0]
        require(0x200 <= root_at <= size - 16, 'Invalid XCI root offset')
        root = _directory(stream, root_at, size - root_at, b'HFS0')
        require('secure' in root, 'XCI secure game partition is missing')
        return _directory(stream, *root['secure'], b'HFS0')


def select(path, pin):
    found = entries(path)
    variants = [pin, *pin.get('program_variants', [])]
    matches = [v for v in variants if v['program_name'] in found]
    require(len(matches) == 1, 'Missing or ambiguous supported base Program NCA; '
            'supply the matching region/base game, not an update-only or modified image')
    selected = matches[0]
    ticket = selected.get('ticket_name')
    require(not ticket or ticket in found, 'Required base Program ticket is missing')
    return dict(entries=found, program_name=selected['program_name'],
                program_sha256=selected['program_sha256'], ticket_name=ticket)


def authenticate(path, pin):
    """Always hash the complete selected Program, even before a warm cache read."""
    selected = select(path, pin)
    require(copy_entry(path, selected['entries'][selected['program_name']]) == selected['program_sha256'],
            'Program NCA identity differs')
    return selected


@contextmanager
def open_program(path, pin, work):
    """Hash while copying; never yield an unverified Program to NSTool."""
    selected = select(path, pin)
    Path(work).mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='switch-source-', dir=work) as temporary:
        root = Path(temporary)
        program = root / selected['program_name']
        require(copy_entry(path, selected['entries'][program.name], program) == selected['program_sha256'],
                'Program NCA identity differs')
        ticket = root / selected['ticket_name'] if selected['ticket_name'] else None
        if ticket is not None:
            copy_entry(path, selected['entries'][ticket.name], ticket)
        yield program, ticket, selected


def extract(nstool, keys, program, ticket, resource_path, destination):
    """Extract a whole parent folder to avoid NSTool's Windows single-file bug."""
    command = [str(nstool), '-k', str(Path(keys).resolve())]
    if ticket is not None:
        command += ['--tik', str(ticket)]
    command += ['-x', str(resource_path), str(destination), str(program)]
    result = subprocess.run(command, capture_output=True, text=True,
                            encoding='utf-8', errors='replace')
    if result.returncode:
        details = '\n'.join(part for part in (result.stdout, result.stderr) if part).strip()
        details = re.sub(r'(?i)\b[0-9a-f]{32,}\b', '[hex value omitted]', details)
        status = f'{result.returncode} (0x{result.returncode & 0xffffffff:08X})'
        raise ValueError('NSTool source extraction failed; exit code ' + status + '\n'
                         + (details[-12000:] or 'NSTool returned no diagnostic output.'))


def resource(nstool, keys, program, ticket, pin, destination):
    from pathlib import PurePosixPath
    path = PurePosixPath(pin['resource_path'])
    Path(destination).mkdir(parents=True, exist_ok=True)
    extract(nstool, keys, program, ticket, path.parent, destination)
    output = Path(destination) / path.name
    require(output.is_file() and file_sha(output) == pin['resource_sha256'],
            'Decrypted regional resource identity differs')
    return output
