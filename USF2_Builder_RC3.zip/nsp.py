"""Read content-pinned NSP/XCI sources with your keys and pinned NSTool."""
from pathlib import Path
import subprocess
import sys
from payload import require, source_key

HERE = Path(__file__).resolve().parent
# Both the kit and standalone output verifiers bundle this standard-library
# helper beside nsp.py. The checkout imports the same canonical tracked file.
if not (HERE/'switch_source.py').is_file():
    sys.path.insert(0, str(HERE.parents[2]/'cpsplus/pack'))
from switch_source import (authenticate, copy_entry, entries, file_sha,
                           open_program, resource, select)


def toolset(work, tools_source=None):
    sys.path.insert(0, str(tools_source or HERE/'sound/tools'))
    import setup_switch_tools
    return setup_switch_tools.setup(Path(work) / 'switch-tools')


def unlock(path, keys, pin, work, tools_source=None):
    require(Path(keys).is_file(), 'Supply your own Switch prod.keys')
    # Reject unsupported containers/regions before preparing the toolchain.
    select(path, pin)
    work = Path(work); work.mkdir(parents=True, exist_ok=True)
    tools = toolset(work, tools_source)
    with open_program(path, pin, work) as (program, ticket, _):
        verified = resource(tools['nstool'], keys, program, ticket, pin, program.parent/'resource')
        return source_key(verified.read_bytes())
