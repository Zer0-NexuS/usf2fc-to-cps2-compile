USF2 RC3 - FIX 6: MinGit checksum repair
=========================================

WHAT THIS FIXES
Fix 5 incorrectly checks MinGit-2.56.0.2-64-bit.zip against SHA-256
ab2543fea7eebdc8476b63af2ff8acec10fce72fc9f72a40c9123df94c6ac1ae
instead of the checksum in the Git for Windows v2.56.0.windows.2 release notes:
da35e72aa21c005a5a0d298cfbae110bc1609a815730ea0dde84b01a1b3cd3be

HOTFIX INSTRUCTIONS (use your existing installation)
1. Close the builder.
2. Extract this ZIP.
3. Copy Setup_Toolchain.ps1 to E:\USF2 Builder RC3\
   and replace the older file.
4. DO NOT delete _portable_tools. Previous Python/GCC downloads are reused.
5. Relaunch USF2_Builder.bat and click BUILD.

The previously rejected MinGit download is normally deleted automatically by
the old checksum check. If not present, it will download once more.

WHAT WAS CHANGED
Exactly one pinned SHA-256 literal in Setup_Toolchain.ps1.
Existing TLS certificate-verification settings remain enabled.
No game kit files, ROMs, NSPs, keys or Python modules were altered.

CHECKSUM SOURCE
https://github.com/git-for-windows/git/releases/tag/v2.56.0.windows.2
https://sourceforge.net/projects/git-for-windows.mirror/files/v2.56.0.windows.2/MinGit-2.56.0.2-64-bit.zip/download

VALIDATION
Source diff and packaged archive integrity were verified.
This Linux workspace cannot execute a complete native Windows build.
