USF2 RC2 BUILDER - FIX 2: PORTABLE PYTHON IMPORT PATH
=====================================================
SYMPTOM
  ModuleNotFoundError: No module named 'nsp'

CAUSE
  The official Windows embeddable Python runs in isolated path mode. Its
  python311._pth did not include the RC2 kit folder, although nsp.py was
  present beside apply.py. PYTHONPATH alone cannot solve isolated-path mode.

QUICK FIX FOR EXISTING INSTALLATION (recommended)
  1. Close the builder and extract this hotfix ZIP.
  2. Copy Setup_Toolchain.ps1 into your existing USF2_Drop_Builder folder,
     next to Build.ps1 and apply.py, and allow Windows to REPLACE the file.
  3. DO NOT delete or replace _portable_tools.
  4. Open USF2_Builder.bat and press BUILD IMAGE again.

  The setup script now adds the relative entry ..\.. to
  _portable_tools\python\python311._pth on each run. This fixes existing and
  fresh installations, including after moving the whole builder folder.
  It then verifies that portable Python can import nsp, payload,
  rom_sources, policy, and stock_mame before running the build.

EXPECTED NEW LOG LINE
  [TOOLS] RC2 kit module imports: ready.

The complete corrected archive also includes this fix if you prefer to
re-extract everything. Keep _portable_tools when applying over an existing
installation so you do not have to redownload Python, GCC, CMake, or Git.

WHAT WAS TESTED
  * Reproduced the missing nsp import with isolated Python search paths.
  * Successfully loaded apply.py after explicitly including the kit root.
  * The kit's eight unit tests pass.
  * Compared all other files against the prior Fix 1 ZIP, byte-for-byte.
  * Verified ZIP CRC/integrity and module file presence.

LIMIT
  The Windows PowerShell launcher and full proprietary-input reconstruction
  have not been run in this Linux environment. This resolves the observed
  module-import failure but does not certify a complete image build.
