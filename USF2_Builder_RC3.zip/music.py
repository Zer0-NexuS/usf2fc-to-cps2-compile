#!/usr/bin/env python3
"""Rebuild the USF2 CPS+ arrangement from owned NSP/XCI music; no pack-input shortcut."""
import argparse
import json
from pathlib import Path
import sys
from nsp import authenticate, file_sha, select, toolset
from payload import require

HERE = Path(__file__).resolve().parent


def build(nsp, keys, pin, out, work, tools_work=None):
    authenticate(nsp, pin)
    require(Path(keys).is_file(), 'Supply your own Switch prod.keys')
    sys.path.insert(0, str(HERE/'sound'))
    from pack import build_usf2_remix as source
    from build_pack import adapt
    # Regional adapters select authenticated Program/resource identities. The
    # final common CPK hash checks every track, loop and trigger independently.
    work = Path(work); work.mkdir(parents=True, exist_ok=True)
    source.switch_tools = lambda _root:toolset(tools_work or work/'source')
    original = work/'original.cpk'
    source.build(Path(nsp).resolve(), Path(keys).resolve(), out=original,
                 work=work/'build', scratch=work/'extract', source_pin=pin)
    commands = json.loads((HERE/'sound/music_commands.json').read_text())
    manifest=json.loads((HERE/'kit.json').read_text())
    if manifest.get('variant_ending_music'):
        from variant_music import obtain,append
        config=json.loads((HERE/'sound/variant_ending_sources.json').read_text())
        alias=work/'native-alias.cpk';adapt(original,alias,commands)
        # adapt writes an audit receipt, not a PackWriter track sidecar.
        # Consume that owned receipt before PackReader looks for track names.
        Path(str(alias)+'.json').unlink()
        paths,tools=obtain(Path(nsp).resolve(),Path(keys).resolve(),pin,config,work/'variant-inputs',
            toolset(tools_work or work/'source'))
        append(alias,Path(out),config,paths,tools['decoder'],work/'variant-encode')
        alias.unlink()
    else:
        adapt(original, Path(out), commands)
    expected = manifest['cpk_sha256']
    require(file_sha(out) == expected, 'Rebuilt CPK differs from the selected arrangement')
    original.unlink(); Path(str(original)+'.json').unlink()
    return Path(out)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', '--nsp', '--xci', dest='nsp', type=Path, required=True); p.add_argument('--keys', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True); p.add_argument('--work', type=Path, required=True)
    a = p.parse_args(); pins = json.loads((HERE/'kit.json').read_text())['nsp']
    found = []
    for pin in pins.values():
        try: select(a.nsp, pin)
        except ValueError: continue
        found.append(pin)
    require(len(found) == 1, 'Unsupported or ambiguous regional base NSP/XCI')
    require(not a.out.exists(), 'Choose a fresh CPK output')
    build(a.nsp, a.keys, found[0], a.out, a.work)
    print('PASS exact NSP/XCI-derived CPS+ arrangement')
