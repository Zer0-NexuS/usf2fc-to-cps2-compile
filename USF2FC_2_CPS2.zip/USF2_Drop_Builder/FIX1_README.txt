USF2 RC2 FIX 1 - 20 OCTOBER 2026
================================

This fixes the incorrect MinGit SHA-256 in Setup_Toolchain.ps1.
The correct checksum for official MinGit-2.56.0.2-64-bit.zip is:
da35e72aa21c005a5a0d298cfbae110bc1609a815730ea0dde84b01a1b3cd3be
Verified from the Git for Windows v2.56.0.windows.2 release page.

FASTEST FIX ON YOUR EXISTING INSTALL:
1. Close the GUI if it is running.
2. Extract this hotfix ZIP into the parent of USF2_Drop_Builder,
   e.g. E:\, and choose to replace Setup_Toolchain.ps1.
   Or directly copy the included Setup_Toolchain.ps1 into
   E:\USF2_Drop_Builder\ overwriting the old copy.
3. Double-click your existing USF2_Builder.bat and try Build again.

Keep E:\USF2_Drop_Builder\_portable_tools! Your previously downloaded
Python and GCC/CMake/Ninja remain there and will be reused.
The failed MinGit ZIP was automatically deleted by the checksum check.
The next run will only need to redownload Git, plus any other missing tools.

Integrity checks remain enabled. This hotfix does not alter apply.py or
any content in the original RC2 reconstruction kit.

Full package users: extract the full Fix1 ZIP to the parent of your existing
USF2_Drop_Builder folder and allow overwriting, while keeping _portable_tools.

NOTE: This fix resolves the downloader checksum failure seen in the log.
It does not establish that an entire Windows game build has passed.
