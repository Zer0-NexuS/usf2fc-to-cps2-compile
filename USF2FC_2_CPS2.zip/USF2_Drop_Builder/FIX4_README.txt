USF2 RC2 DROP BUILDER - FIX 4: PORTABLE GIT HTTPS CERTIFICATES

Problem
  fatal: ... error adding trust anchors from file:
  C:/Program Files/Git/mingw64/etc/ssl/certs/ca-bundle.crt

Fix
  Sets Git's http.sslBackend to 'schannel' and
  http.schannelUseSSLCAInfo to false. Git uses the native Windows
  trusted certificate store, with http.sslVerify=true.
  These settings apply only to the builder process and its nested Git clones.
  Global/system Git configuration is NOT changed.

INSTALL (for anyone already using Fix 3):
  1. Close the builder.
  2. Extract this ZIP.
  3. Copy Setup_Toolchain.ps1 over:
       E:\USF2_Drop_Builder\Setup_Toolchain.ps1
  4. Do NOT delete _portable_tools.
  5. Launch USF2_Builder.bat and rebuild.

What to expect:
  [TOOLS] Portable Git: ready (Windows trusted certificates; TLS verification enabled).

Scope:
  Only Setup_Toolchain.ps1 has changed since Fix 3.
  No game data, keys, or ROM files are included in the hotfix.

Verified by static inspection and kit self-tests. Windows Git clone
  and a complete game-image build still require on-machine testing.
